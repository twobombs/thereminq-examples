Highly compressed multithreaded ACE Ising depth tests visualisations


![mag_vs_sec_heatmap](https://github.com/user-attachments/assets/784a2115-1009-40c4-a18e-ed134fe0ae95)
![Screenshot from 2025-06-09 14-39-43](https://github.com/user-attachments/assets/18ae217c-b28b-42ab-8949-2a6a4c4ebcd7)
![magnetization_heatmap](https://github.com/user-attachments/assets/25e3922f-a12a-4c6b-be4d-0926196a17f5)
![magnetization_vs_depth](https://github.com/user-attachments/assets/0d47151d-fb24-44b9-b09b-24e138148149)
![seconds_vs_depth](https://github.com/user-attachments/assets/bc7327e7-b58a-442e-a158-d2e15954f764)
![avg_magnetization_vs_width](https://github.com/user-attachments/assets/5040cc81-f8f9-4377-a0ba-fea8c379f061)
![magnetization_vs_seconds](https://github.com/user-attachments/assets/2d2cf00f-2762-4b2d-899d-2187601bdee1)
![boxplot_magnetization_vs_width](https://github.com/user-attachments/assets/ab8bc839-486f-4969-b3e2-e347f5d0e048)


https://g.co/gemini/share/fe558030b59b

![Code_Generated_Image](https://github.com/user-attachments/assets/8152a5c8-2680-4fcf-9717-261d077ea955)
![Code_Generated_Image (1)](https://github.com/user-attachments/assets/7dd64d33-bdf9-438e-a7c9-75d199d8857e)
![Code_Generated_Image (2)](https://github.com/user-attachments/assets/08bdcbc0-933b-4f78-8bc2-733f7cb19ffc)
![Code_Generated_Image (3)](https://github.com/user-attachments/assets/d71832d3-10e0-4243-8680-743917de3e4f)

row/collum vs qubits settings
![Screenshot_from_2025-06-14_09-40-41](https://github.com/user-attachments/assets/566b2b9f-b14a-4b6d-bfa9-40ae81e30225)
