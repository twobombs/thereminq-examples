for d in {1..20}; do python3 ising_ace_validation.py 16 $d 2048 1 4; done
