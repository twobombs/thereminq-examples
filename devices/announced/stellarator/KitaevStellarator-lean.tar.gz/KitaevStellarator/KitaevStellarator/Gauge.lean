import KitaevStellarator.Lattice
import KitaevStellarator.Pauli

/-!
# Flux sector of the stellarator: plaquettes, block cycles, seam-repair strings

The 260 loops are the 200 in-shell plaquettes (12-cycles) and the 60 block-internal
8-cycles that the PyQrack worker reads out by in-place parity folding.

* `loops_are_cycles`   : each loop is a closed walk of distinct sites along bonds,
                         and every site meets it in 0 or 2 bonds
* `gauge_invariance`   : every loop operator `W_ℓ` commutes with every one of the
                         1620 Kitaev bond terms (from `kitaev_loop_commutes`)
* `words_match_manifest` : the letters derived here equal the Pauli words the
                         manifest (and the QASM emitter) uses for the 60 block cycles
* `fluxes_commute`     : all 260 loop operators commute pairwise
* `repair_gauge_safe`  : all 1800 `Sigma_keep` seam-repair Pauli strings
                         (45 per block) commute with all 260 loop operators, so
                         seam repair cannot create visons
-/

namespace Stellarator
open Data Pauli

def NL : Nat := 260
def NR : Nat := 1800

@[irreducible] def loopAt (ℓ : Nat) : Array Nat := loops[ℓ]!

/-- step `i` of loop `ℓ` is the bond `(v, nbr v c)` -/
def stepHits (ℓ i v c : Nat) : Bool :=
  let L := loopAt ℓ
  let a := L[i]!
  let b := L[(i + 1) % L.size]!
  (a == v && nbr v c == b) || (b == v && nbr v c == a)

/-- bond `(v, colour c)` belongs to loop `ℓ` -/
def inLoop (ℓ v c : Nat) : Bool := (List.range (loopAt ℓ).size).any (fun i => stepHits ℓ i v c)

theorem stepHits_symm {ℓ i v c : Nat} (hv : v < N) (hc : c < 3) :
    stepHits ℓ i (nbr v c) c = stepHits ℓ i v c := by
  have h1 := nbr_invol v hv c hc
  unfold stepHits
  generalize (loopAt ℓ)[i]! = a
  generalize (loopAt ℓ)[(i + 1) % (loopAt ℓ).size]! = b
  rw [h1]
  generalize nbr v c = w
  rw [Bool.eq_iff_iff]
  simp only [Bool.or_eq_true, Bool.and_eq_true, beq_iff_eq]
  omega

theorem inLoop_symm {ℓ v c : Nat} (hv : v < N) (hc : c < 3) :
    inLoop ℓ (nbr v c) c = inLoop ℓ v c := by
  unfold inLoop
  congr 1
  funext i
  exact stepHits_symm hv hc

/-! ## Certificates -/

theorem loops_size : loops.size = NL := by native_decide

theorem loops_degree : ∀ ℓ < NL, ∀ v < N,
    degOK (inLoop ℓ v 0) (inLoop ℓ v 1) (inLoop ℓ v 2) = true := by
  native_decide

/-- Each loop is a simple closed walk along bonds of length ≥ 4. -/
theorem loops_are_cycles : ∀ ℓ < NL,
    4 ≤ (loopAt ℓ).size ∧ (loopAt ℓ).toList.Nodup ∧
    ∀ i < (loopAt ℓ).size, ∃ c < 3,
      nbr (loopAt ℓ)[i]! c = (loopAt ℓ)[(i + 1) % (loopAt ℓ).size]! := by
  native_decide

/-- Length census: 200 in-shell 12-cycles; the 60 block cycles are 50 radial 8-cycles
and 10 cap 4-cycles (axis / divertor closures). -/
theorem loop_lengths :
    (∀ ℓ < 200, (loopAt ℓ).size = 12) ∧
    ((List.range 60).filter (fun j => (loopAt (200 + j)).size = 8)).length = 50 ∧
    ((List.range 60).filter (fun j => (loopAt (200 + j)).size = 4)).length = 10 := by
  native_decide

/-! ## Loop operators on the lattice -/

/-- the lattice as an abstract colour graph on `Fin N` -/
def nbrF (v : Fin N) (c : Fin 3) : Fin N := ⟨nbr v c, nbr_lt v v.2 c c.2⟩

/-- loop `ℓ` as an even edge set -/
def loopSet (ℓ : Nat) (hℓ : ℓ < NL) : EvenSet nbrF where
  mem v c := inLoop ℓ v c
  symm v c := inLoop_symm v.2 c.2
  deg v := loops_degree ℓ hℓ v v.2

/-- letter of `W_ℓ` at site `v` -/
def wAt (ℓ v : Nat) : P1 := wLetter (inLoop ℓ v 0) (inLoop ℓ v 1) (inLoop ℓ v 2)

/-- **Gauge invariance.** Every plaquette / block-cycle operator commutes with every
Kitaev bond term `σ^c_v σ^c_{nbr v c}` of the 1080-site machine. -/
theorem gauge_invariance (ℓ : Nat) (hℓ : ℓ < NL) (v : Nat) (hv : v < N) (c : Nat) (hc : c < 3) :
    Even ((if anti (wAt ℓ v) (some ⟨c, hc⟩) then 1 else 0) +
          (if anti (wAt ℓ (nbr v c)) (some ⟨c, hc⟩) then 1 else 0)) :=
  kitaev_loop_commutes (loopSet ℓ hℓ) ⟨v, hv⟩ ⟨c, hc⟩

/-- In particular for every listed bond. -/
theorem gauge_invariance_bonds (ℓ : Nat) (hℓ : ℓ < NL) {a b c : Nat} (h : Bond a b c) :
    ∃ hc : c < 3, Even ((if anti (wAt ℓ a) (some ⟨c, hc⟩) then 1 else 0) +
                        (if anti (wAt ℓ b) (some ⟨c, hc⟩) then 1 else 0)) := by
  obtain ⟨ha, -, hc⟩ := h.lt
  exact ⟨hc, h.nbr_eq ▸ gauge_invariance ℓ hℓ a ha c hc⟩

/-- the letter `c` as a `P1` (out-of-range colours read as identity) -/
def letterOf (c : Nat) : P1 := if h : c < 3 then some ⟨c, h⟩ else none

/-- The letters of the 60 block cycles agree with the manifest words (`pauli_local`). -/
theorem words_match_manifest : ∀ j < 60,
    (wordSites[j]!).size = (loopAt (200 + j)).size ∧
    (∀ k < (wordSites[j]!).size,
      wAt (200 + j) (wordSites[j]!)[k]! = letterOf (wordCols[j]!)[k]!) ∧
    (∀ s ∈ (loopAt (200 + j)).toList, s ∈ (wordSites[j]!).toList) := by
  native_decide

/-- `W_ℓ` acts as the identity off its own loop -/
theorem wAt_support : ∀ ℓ < NL, ∀ v < N, v ∉ (loopAt ℓ).toList → wAt ℓ v = none := by
  native_decide

/-- number of anticommuting sites of `W_ℓ` and `W_m` (only sites of loop `ℓ` can count,
by `wAt_support`) -/
def loopAnti (ℓ m : Nat) : Nat :=
  ((loopAt ℓ).toList.filter (fun v => anti (wAt ℓ v) (wAt m v))).length

/-- All 260 flux operators commute with each other. -/
theorem fluxes_commute : ∀ ℓ < NL, ∀ m < NL, Even (loopAnti ℓ m) := by native_decide

/-- number of anticommuting sites of repair string `r` and `W_ℓ` -/
def repAnti (r ℓ : Nat) : Nat :=
  ((List.range (repSites[r]!).size).filter
    (fun k => anti (letterOf (repCols[r]!)[k]!) (wAt ℓ (repSites[r]!)[k]!))).length

/-- **Seam repair is gauge safe.** Each of the 1800 retained `Sigma_keep` Pauli strings
has distinct sites inside its own block, only x/y/z letters, length 2 or 4, and
commutes with every one of the 260 flux operators. -/
theorem repair_gauge_safe :
    repSites.size = NR ∧
    ∀ r < NR, ((repSites[r]!).size = 2 ∨ (repSites[r]!).size = 4) ∧
      (repCols[r]!).size = (repSites[r]!).size ∧
      (repSites[r]!).toList.Nodup ∧
      (∀ k < (repSites[r]!).size, (repCols[r]!)[k]! < 3 ∧
          blockOf[(repSites[r]!)[k]!]! = repBlock[r]!) ∧
      ∀ ℓ < NL, Even (repAnti r ℓ) := by
  native_decide

end Stellarator

namespace Stellarator
open Data

/-- 861 two-site (bond) and 939 four-site repair strings, 45 per block. -/
theorem repair_census :
    ((List.range NR).filter (fun r => (repSites[r]!).size = 2)).length = 861 ∧
    ((List.range NR).filter (fun r => (repSites[r]!).size = 4)).length = 939 ∧
    ∀ k < 40, ((List.range NR).filter (fun r => repBlock[r]! = k)).length = 45 := by
  native_decide

end Stellarator
