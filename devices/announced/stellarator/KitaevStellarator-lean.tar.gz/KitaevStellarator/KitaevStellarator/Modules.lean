import KitaevStellarator.Gauge

/-!
# Modular decomposition: 10 half-period modules × 4 manifolds of 27 qubits

* `partition`          : 40 blocks of exactly 27 sites cover the 1080 sites
* `block_in_module`    : block `k` lies in module `k / 4`
* `block_connected`    : any two sites of a block are joined by a path of
                         *internal* bonds (each block is a connected manifold)
* `bond_classes`       : 1100 internal + 320 K4 intra-module + 200 toroidal seam bonds,
                         and no bond reaches further than the neighbouring module
* `k4_all_to_all`      : inside every module all 6 block pairs share ≥ 2 seam bonds
* `toroidal_ring`      : each of the 10 module boundaries carries exactly 20 seam bonds
* `spanning_forest`    : 1040 = 1080 − 40 distinct internal tree bonds
* `cycle_rank`         : internal cycle rank 1100 − 1080 + 40 = 60
* `block_cycles_independent` : the 60 block cycles are GF(2)-independent, so they
                         realise all 60 independent internal cycles
-/

namespace Stellarator
open Data Relation

@[irreducible] def blk (s : Nat) : Nat := blockOf[s]!
@[irreducible] def root (k : Nat) : Nat := blockRoot[k]!
@[irreducible] def bc (s : Nat) : Nat := bcol[s]!
@[irreducible] def bd (s : Nat) : Nat := bdepth[s]!

/-- parent of `s` in the block spanning forest -/
def bpar (s : Nat) : Nat := nbr s (bc s)

/-! ## Partition -/

theorem partition :
    (∀ s < N, blk s < 40) ∧ ∀ k < 40, ((List.range N).filter (fun s => blk s = k)).length = 27 := by
  native_decide

theorem block_in_module : ∀ s < N, blk s / 4 = modOf[s]! ∧ modOf[s]! < 10 := by native_decide

/-! ## Connectivity of every block -/

/-- `a` and `b` are joined by an internal bond of their block -/
def IntAdj (a b : Nat) : Prop := a < N ∧ ∃ c < 3, nbr a c = b ∧ blk a = blk b

theorem IntAdj.bond {a b : Nat} (h : IntAdj a b) : ∃ c, Bond a b c := by
  obtain ⟨ha, c, hc, rfl, -⟩ := h
  exact ⟨c, table_complete a ha c hc⟩

theorem IntAdj.symm' {a b : Nat} (h : IntAdj a b) : IntAdj b a := by
  obtain ⟨ha, c, hc, rfl, hb⟩ := h
  exact ⟨nbr_lt a ha c hc, c, hc, nbr_invol a ha c hc, hb.symm⟩

theorem forest_cert :
    (∀ k < 40, root k < N ∧ blk (root k) = k ∧ bc (root k) = 3) ∧
    (∀ s < N, bc s = 3 ∨ (bc s < 3 ∧ blk (bpar s) = blk s ∧ bd (bpar s) < bd s)) ∧
    (∀ s < N, bc s = 3 → s = root (blk s)) := by
  native_decide

theorem to_root : ∀ s < N, ReflTransGen IntAdj s (root (blk s)) := by
  intro s hs
  induction h : bd s using Nat.strong_induction_on generalizing s with
  | _ n ih =>
    rcases forest_cert.2.1 s hs with h3 | ⟨hc, hb, hd⟩
    · rw [← forest_cert.2.2 s hs h3]
    · have hp : bpar s < N := by unfold bpar; exact nbr_lt s hs _ hc
      have hrec := ih (bd (bpar s)) (h ▸ hd) (bpar s) hp rfl
      rw [hb] at hrec
      exact ReflTransGen.head ⟨hs, bc s, hc, rfl, hb.symm⟩ hrec

/-- **Every 27-qubit manifold is connected through its own internal bonds.** -/
theorem block_connected : ∀ a < N, ∀ b < N, blk a = blk b → ReflTransGen IntAdj a b := by
  intro a ha b hb hab
  have hsym : ∀ {x y}, ReflTransGen IntAdj x y → ReflTransGen IntAdj y x := by
    intro x y h
    induction h with
    | refl => exact .refl
    | tail _ hyz ih => exact ReflTransGen.head hyz.symm' ih
  exact (to_root a ha).trans (hab ▸ hsym (to_root b hb))

/-! ## Seam structure -/

def modOfS (s : Nat) : Nat := blk s / 4

/-- 0 internal, 1 K4 (same module), 2 toroidal (neighbouring modules), 3 other -/
def bondKind (i : Nat) : Nat :=
  let a := bondA[i]!
  let b := bondB[i]!
  if blk a = blk b then 0
  else if modOfS a = modOfS b then 1
  else if (modOfS a + 1) % 10 = modOfS b ∨ (modOfS b + 1) % 10 = modOfS a then 2
  else 3

def kindCount (k : Nat) : Nat := ((List.range NB).filter (fun i => bondKind i = k)).length

theorem bond_classes :
    kindCount 0 = 1100 ∧ kindCount 1 = 320 ∧ kindCount 2 = 200 ∧ kindCount 3 = 0 := by
  native_decide

def pairCount (x y : Nat) : Nat :=
  ((List.range NB).filter (fun i =>
    (blk bondA[i]! = x ∧ blk bondB[i]! = y) ∨ (blk bondA[i]! = y ∧ blk bondB[i]! = x))).length

/-- K4 cluster: in each module every pair of its 4 blocks is coupled by ≥ 2 seam bonds
(the CP-SAT constraint), 32 K4 bonds per module. -/
theorem k4_all_to_all : ∀ m < 10,
    (∀ x < 4, ∀ y < 4, x < y → 2 ≤ pairCount (4 * m + x) (4 * m + y)) ∧
    ((List.range NB).filter (fun i => bondKind i = 1 ∧ modOfS bondA[i]! = m)).length = 32 := by
  native_decide

/-- The 10 modules form a ring with exactly 20 seam bonds on each boundary `m | m+1`. -/
theorem toroidal_ring : ∀ m < 10,
    ((List.range NB).filter (fun i => bondKind i = 2 ∧
      ((modOfS bondA[i]! = m ∧ modOfS bondB[i]! = (m + 1) % 10) ∨
       (modOfS bondB[i]! = m ∧ modOfS bondA[i]! = (m + 1) % 10)))).length = 20 := by
  native_decide

/-! ## Cycle rank -/

theorem nonroot_count : ((List.range N).filter (fun s => bc s < 3)).length = 1040 := by
  native_decide

/-- Tree bonds of different non-root sites are different bonds: the bond `{s, bpar s}`
is never the bond `{t, bpar t}` reversed (and `s ≠ t` rules out the same orientation). -/
theorem tree_bonds_distinct {s t : Nat} (hs : s < N) (ht : t < N) (hs' : bc s < 3)
    (ht' : bc t < 3) :
    ¬ (s = bpar t ∧ t = bpar s) := by
  rintro ⟨h1, h2⟩
  have ds := forest_cert.2.1 s hs
  have dt := forest_cert.2.1 t ht
  rcases ds with h | ⟨-, -, ds⟩
  · omega
  rcases dt with h | ⟨-, -, dt⟩
  · omega
  rw [← h2] at ds; rw [← h1] at dt; omega

/-- The block spanning forest uses 1040 internal bonds (one per non-root site), so
1100 − 1040 = 60 internal bonds close independent cycles: cycle rank `E − V + c`. -/
theorem cycle_rank : kindCount 0 = (N - 40) + 60 ∧ 1100 - 1080 + 40 = 60 := by
  refine ⟨?_, rfl⟩
  rw [bond_classes.1]; rfl

/-- bond `i` lies on loop `ℓ` -/
def bondOnLoop (ℓ i : Nat) : Bool := inLoop ℓ bondA[i]! bondC[i]!

theorem independence_cert : indOrder.size = 60 ∧ indOrder.toList.Nodup ∧
    ∀ t < 60, indOrder[t]! < 60 ∧ indPriv[t]! < NB ∧ bondOnLoop (200 + indOrder[t]!) indPriv[t]! = true ∧
      ∀ u < 60, t < u → bondOnLoop (200 + indOrder[u]!) indPriv[t]! = false := by
  native_decide

/-- **The 60 block cycles are linearly independent over GF(2)**: every nonempty set of
them has some bond covered an odd number of times, i.e. their sum is not 0. -/
theorem block_cycles_independent (S : Finset (Fin 60)) (hS : S.Nonempty) :
    ∃ i < NB, Odd (S.filter (fun t => bondOnLoop (200 + indOrder[t.1]!) i = true)).card := by
  obtain ⟨-, -, cert⟩ := independence_cert
  let t0 := S.min' hS
  obtain ⟨-, hi, hon, hoff⟩ := cert t0.1 t0.2
  refine ⟨indPriv[t0.1]!, hi, ?_⟩
  have : S.filter (fun t => bondOnLoop (200 + indOrder[t.1]!) indPriv[t0.1]! = true) = {t0} := by
    ext t
    simp only [Finset.mem_filter, Finset.mem_singleton]
    constructor
    · rintro ⟨htS, hon'⟩
      by_contra hne
      have hlt : t0 < t := lt_of_le_of_ne (S.min'_le t htS) (Ne.symm hne)
      rw [hoff t.1 t.2 hlt] at hon'
      exact absurd hon' (by simp)
    · rintro rfl; exact ⟨S.min'_mem hS, hon⟩
  rw [this, Finset.card_singleton]; exact odd_one

end Stellarator
