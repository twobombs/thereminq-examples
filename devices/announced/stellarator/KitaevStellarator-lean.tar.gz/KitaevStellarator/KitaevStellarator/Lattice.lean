import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import KitaevStellarator.Data

/-!
# The 1080-site Kitaev stellarator lattice

`Bond a b c` is the primitive relation read from `manifest.json`. Everything
else (the neighbour table, the bipartition) is a certificate that is checked
against `Bond` here. Results:

* `bond_iff`          : the colour-`c` neighbour of `a` is unique and given by `nbr a c`
* `cubic_proper`      : every site has exactly one bond of each colour x, y, z
* `degree_three`      : every site is the endpoint of exactly 3 of the 1620 bonds
* `bonds_simple`      : no self-bonds and no doubled bonds
* `bipartite`         : the lattice is bipartite
* `shell_split`       : 1380 in-shell bonds + 240 radial rungs, nothing else
* `cubic_handshake`   : (general, Mathlib) any cubic graph has `2|E| = 3|V|`
-/

namespace Stellarator
open Data

def N : Nat := 1080
def NB : Nat := 1620

/-- colour-`c` neighbour of `v` (certificate table) -/
@[irreducible] def nbr (v c : Nat) : Nat := nbrTab[3 * v + c]!

/-- `Bond a b c` : the manifest lists a bond of colour `c` between `a` and `b`. -/
def Bond (a b c : Nat) : Prop :=
  ∃ i < NB, ((bondA[i]! = a ∧ bondB[i]! = b) ∨ (bondA[i]! = b ∧ bondB[i]! = a)) ∧ bondC[i]! = c

instance (a b c : Nat) : Decidable (Bond a b c) := by unfold Bond; infer_instance

/-! ## Certificates (checked by compiled evaluation) -/

theorem sizes : bondA.size = NB ∧ bondB.size = NB ∧ bondC.size = NB ∧ nbrTab.size = 3 * N := by
  native_decide

theorem bond_check : ∀ i < NB,
    bondA[i]! < N ∧ bondB[i]! < N ∧ bondC[i]! < 3 ∧
    nbr bondA[i]! bondC[i]! = bondB[i]! ∧ nbr bondB[i]! bondC[i]! = bondA[i]! := by
  native_decide

theorem nbr_lt : ∀ v < N, ∀ c < 3, nbr v c < N := by native_decide
theorem nbr_invol : ∀ v < N, ∀ c < 3, nbr (nbr v c) c = v := by native_decide
theorem nbr_ne_self : ∀ v < N, ∀ c < 3, nbr v c ≠ v := by native_decide
theorem nbr_distinct : ∀ v < N, nbr v 0 ≠ nbr v 1 ∧ nbr v 0 ≠ nbr v 2 ∧ nbr v 1 ≠ nbr v 2 := by
  native_decide
theorem table_complete : ∀ v < N, ∀ c < 3, Bond v (nbr v c) c := by native_decide

/-! ## Structure -/

theorem Bond.lt {a b c : Nat} (h : Bond a b c) : a < N ∧ b < N ∧ c < 3 := by
  obtain ⟨i, hi, hab, hc⟩ := h
  obtain ⟨h1, h2, h3, -, -⟩ := bond_check i hi
  rcases hab with ⟨h1', h2'⟩ | ⟨h1', h2'⟩ <;> exact ⟨by omega, by omega, by omega⟩

theorem Bond.symm {a b c : Nat} (h : Bond a b c) : Bond b a c := by
  obtain ⟨i, hi, hab, hc⟩ := h
  exact ⟨i, hi, hab.symm, hc⟩

theorem Bond.nbr_eq {a b c : Nat} (h : Bond a b c) : nbr a c = b := by
  obtain ⟨i, hi, hab, hc⟩ := h
  obtain ⟨-, -, -, h4, h5⟩ := bond_check i hi
  rcases hab with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · rw [← h1, ← h2, ← hc]; exact h4
  · rw [← h1, ← h2, ← hc]; exact h5

/-- The colour-`c` bond at `a` exists and ends at `nbr a c`. -/
theorem bond_iff {a b c : Nat} (ha : a < N) (hc : c < 3) : Bond a b c ↔ nbr a c = b :=
  ⟨Bond.nbr_eq, fun h => h ▸ table_complete a ha c hc⟩

/-- Proper 3-edge-colouring of a cubic graph: one bond of each colour at every site. -/
theorem cubic_proper : ∀ v < N, ∀ c < 3, ∃! b, Bond v b c := fun v hv c hc =>
  ⟨nbr v c, table_complete v hv c hc, fun _ hb => hb.nbr_eq.symm⟩

/-- Every site is an endpoint of exactly three of the 1620 listed bonds. -/
theorem degree_three : ∀ v < N,
    ((List.range NB).filter (fun i => bondA[i]! = v ∨ bondB[i]! = v)).length = 3 := by
  native_decide

/-- No self-bonds, no doubled bonds. -/
theorem bonds_simple : ∀ i < NB, bondA[i]! ≠ bondB[i]! ∧ ∀ j < i,
    ¬ ((bondA[i]! = bondA[j]! ∧ bondB[i]! = bondB[j]!) ∨
       (bondA[i]! = bondB[j]! ∧ bondB[i]! = bondA[j]!)) := by
  native_decide

theorem side_check : ∀ i < NB, side[bondA[i]!]! + side[bondB[i]!]! = 1 := by native_decide

private theorem beq_zero_ne {x y : Nat} (h : x + y = 1) : (x == 0) ≠ (y == 0) := by
  intro heq
  rcases Nat.eq_zero_or_pos x with rfl | hx
  · simp at heq; omega
  · have hy : y = 0 := by omega
    subst hy; simp at heq; omega

/-- The lattice is bipartite (Candidate H). -/
theorem bipartite : ∃ f : Nat → Bool, ∀ a b c, Bond a b c → f a ≠ f b := by
  refine ⟨fun v => side[v]! == 0, fun a b c ⟨i, hi, hab, _⟩ => ?_⟩
  have := side_check i hi
  rcases hab with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> rw [← h1, ← h2]
  · exact beq_zero_ne this
  · exact (beq_zero_ne this).symm

/-- 1380 bonds stay on one flux shell (incl. axis and divertor caps), 240 are radial
rungs between neighbouring shells, and there is no other kind of bond. -/
theorem shell_split :
    ((List.range NB).filter (fun i => shellOf[bondA[i]!]! = shellOf[bondB[i]!]!)).length = 1380 ∧
    ((List.range NB).filter (fun i => shellOf[bondA[i]!]! + 1 = shellOf[bondB[i]!]! ∨
                                       shellOf[bondB[i]!]! + 1 = shellOf[bondA[i]!]!)).length = 240 ∧
    (∀ v < N, shellOf[v]! < 5) := by
  native_decide

/-! ## Handshake lemma (general) -/

/-- Any finite cubic simple graph satisfies `2 |E| = 3 |V|`; in particular `|V|` is even. -/
theorem cubic_handshake {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (h : ∀ v, G.degree v = 3) :
    2 * G.edgeFinset.card = 3 * Fintype.card V := by
  rw [← G.sum_degrees_eq_twice_card_edges]
  simp [h, Finset.sum_const, Finset.card_univ, mul_comm]

theorem bond_count : 2 * NB = 3 * N := by decide

end Stellarator
