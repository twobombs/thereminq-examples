import KitaevStellarator.Modules

/-!
# Symmetry: the coloured lattice is rigid

The code builds its 4 block classes from a module-local labelling (`loc_to_glob[m]`),
treating the 10 half-period modules as images of each other under the `D5` group.
Here we check what that labelling does on the actual lattice.

* `rigid`               : any map of sites that sends every bond of colour `c` to a bond
                          of colour `π c`, for a colour map `π` with `π x ≠ π y`, is the
                          identity with `π = id` (only `π 0 ≠ π 1` is needed; constant
                          colour maps give the folds onto one bond, see `candidates`). The coloured 1080-site lattice has
                          **no** nontrivial symmetry, so no element of `D5` acts on it.
* `shift_perm`, `shift_blocks` : the module shift `m ↦ m + 1` of the code's labelling is
                          a permutation of sites that maps block `k` to block `k + 4`
* `shift_keeps_modules` : it preserves every internal and every K4 bond with its colour
* `shift_breaks_closure`: it fails on exactly 40 bonds, all of them toroidal seams on the
                          boundaries `8|9` and `9|0`; the closing seam `9|0` is wired
                          with a one-connector poloidal offset (`closing_seam_offset`)
* `shift_not_symmetry`  : so the shift is not a lattice automorphism

The 4 block "types" are therefore exact as *module templates* (identical internal
coloured graphs, the property the 27-qubit circuits need), not as orbits of a
lattice symmetry.
-/

namespace Stellarator
open Data

@[irreducible] def gc (s : Nat) : Nat := gcol[s]!
@[irreducible] def gd (s : Nat) : Nat := gdepth[s]!
def gpar (s : Nat) : Nat := nbr s (gc s)

/-- a colour map given by its three values -/
def cmap (p : Nat × Nat × Nat) (c : Nat) : Nat :=
  if c = 0 then p.1 else if c = 1 then p.2.1 else p.2.2

/-- the unique candidate map with `0 ↦ v` and colours mapped by `p`, propagated along
the BFS tree from site 0 -/
def phiArr (v : Nat) (p : Nat × Nat × Nat) : Array Nat :=
  gorder.foldl (fun acc s =>
    if s = 0 then acc.set! 0 v else acc.set! s (nbr acc[gpar s]! (cmap p (gc s))))
    (Array.replicate N 0)

def phiEqs (ph : Array Nat) (v : Nat) (p : Nat × Nat × Nat) : Prop :=
  ph[0]! = v ∧ ∀ s < N, s ≠ 0 → ph[s]! = nbr ph[gpar s]! (cmap p (gc s))

instance (ph : Array Nat) (v : Nat) (p : Nat × Nat × Nat) : Decidable (phiEqs ph v p) := by
  unfold phiEqs; infer_instance

def preserves (ph : Array Nat) (p : Nat × Nat × Nat) : Prop :=
  ∀ i < NB, nbr ph[bondA[i]!]! (cmap p bondC[i]!) = ph[bondB[i]!]!

instance (ph : Array Nat) (p : Nat × Nat × Nat) : Decidable (preserves ph p) := by
  unfold preserves; infer_instance

theorem tree_cert : ∀ s < N, s ≠ 0 → gc s < 3 ∧ gd (gpar s) < gd s := by native_decide

/-- All 27 · 1080 candidates: the propagation equations hold, and a candidate preserves
the bonds only if it is the identity or its colour map is constant (a fold of the
bipartite lattice onto a single bond). -/
def candOK (v p0 p1 p2 : Nat) : Prop :=
  phiEqs (phiArr v (p0, p1, p2)) v (p0, p1, p2) ∧
  (preserves (phiArr v (p0, p1, p2)) (p0, p1, p2) →
    (v = 0 ∧ p0 = 0 ∧ p1 = 1 ∧ p2 = 2) ∨ (p0 = p1 ∧ p1 = p2))

instance (v p0 p1 p2 : Nat) : Decidable (candOK v p0 p1 p2) := by unfold candOK; infer_instance

theorem candidates : ∀ v < N, ∀ p0 < 3, ∀ p1 < 3, ∀ p2 < 3, candOK v p0 p1 p2 := by
  native_decide

theorem phi_id : ∀ s < N, (phiArr 0 (0, 1, 2))[s]! = s := by native_decide

theorem cmap_eq (π : Nat → Nat) {c : Nat} (hc : c < 3) : cmap (π 0, π 1, π 2) c = π c := by
  unfold cmap
  rcases (by omega : c = 0 ∨ c = 1 ∨ c = 2) with rfl | rfl | rfl <;> simp

/-- **Rigidity.** A site map `f` with an injective colour map `π` that carries bonds to
bonds is the identity, and `π` is the identity on colours. -/
theorem rigid (f π : Nat → Nat) (hπ : ∀ c < 3, π c < 3) (hinj : π 0 ≠ π 1)
    (hf : ∀ a b c, Bond a b c → Bond (f a) (f b) (π c)) :
    (∀ c < 3, π c = c) ∧ ∀ s < N, f s = s := by
  set p : Nat × Nat × Nat := (π 0, π 1, π 2) with hp
  have hv : f 0 < N :=
    (hf _ _ _ (table_complete 0 (by decide) 0 (by decide))).lt.1
  obtain ⟨heqs, hcand⟩ := candidates (f 0) hv (π 0) (hπ 0 (by decide)) (π 1) (hπ 1 (by decide))
    (π 2) (hπ 2 (by decide))
  set ph := phiArr (f 0) p with hph
  -- f agrees with the propagated candidate
  have hagree : ∀ s < N, f s = ph[s]! := by
    intro s hs
    induction h : gd s using Nat.strong_induction_on generalizing s with
    | _ n ih =>
      by_cases h0 : s = 0
      · subst h0; exact heqs.1.symm
      obtain ⟨hc, hd⟩ := tree_cert s hs h0
      have hpN : gpar s < N := by unfold gpar; exact nbr_lt s hs _ hc
      have hpar := ih (gd (gpar s)) (h ▸ hd) (gpar s) hpN rfl
      have hb : Bond s (gpar s) (gc s) := table_complete s hs _ hc
      have hb' := (hf _ _ _ hb).symm.nbr_eq
      rw [heqs.2 s hs h0, ← hpar, cmap_eq π hc, hb']
  have hpres : preserves ph p := by
    intro i hi
    obtain ⟨ha, hb, hc, -, -⟩ := bond_check i hi
    have hbond : Bond bondA[i]! bondB[i]! bondC[i]! := ⟨i, hi, Or.inl ⟨rfl, rfl⟩, rfl⟩
    rw [← hagree _ ha, ← hagree _ hb, cmap_eq π hc]
    exact (hf _ _ _ hbond).nbr_eq
  obtain ⟨h0, h1, h2, h3⟩ | ⟨h01, -⟩ := hcand hpres
  swap
  · exact absurd h01 hinj
  refine ⟨fun c hc => ?_, fun s hs => ?_⟩
  · rcases (by omega : c = 0 ∨ c = 1 ∨ c = 2) with rfl | rfl | rfl <;> assumption
  · rw [hagree s hs, hph, hp, h0, h1, h2, h3]; exact phi_id s hs

/-! ## The module shift used for the block classes -/

@[irreducible] def shift (s : Nat) : Nat :=
  glob[((modOf[s]! + 1) % 10) * 108 + locOf[s]!]!

@[irreducible] def unshift (s : Nat) : Nat :=
  glob[((modOf[s]! + 9) % 10) * 108 + locOf[s]!]!

theorem shift_perm : ∀ s < N, shift s < N ∧ unshift s < N ∧
    unshift (shift s) = s ∧ shift (unshift s) = s := by native_decide

theorem shift_blocks : ∀ s < N, blk (shift s) = (blk s + 4) % 40 := by native_decide

def shiftKeeps (i : Nat) : Bool := nbr (shift bondA[i]!) bondC[i]! == shift bondB[i]!

theorem shift_keeps_modules : ∀ i < NB, bondKind i ≤ 1 → shiftKeeps i = true := by native_decide

theorem shift_breaks_closure :
    ((List.range NB).filter (fun i => shiftKeeps i = false)).length = 40 ∧
    ∀ i < NB, shiftKeeps i = false → bondKind i = 2 ∧
      (modOfS bondA[i]! = 9 ∨ modOfS bondB[i]! = 9) := by
  native_decide

/-- Local wiring of the boundary `m | m+1`: the (local label in `m`, local label in `m+1`)
pairs of its 20 seam bonds. -/
def seamWiring (m : Nat) : List (Nat × Nat) :=
  ((List.range NB).filterMap (fun i =>
    let a := bondA[i]!
    let b := bondB[i]!
    if modOf[a]! = m ∧ modOf[b]! = (m + 1) % 10 then some (locOf[a]!, locOf[b]!)
    else if modOf[b]! = m ∧ modOf[a]! = (m + 1) % 10 then some (locOf[b]!, locOf[a]!)
    else none)).mergeSort (fun x y => decide (x ≤ y))

/-- Boundaries `0|1 … 8|9` are wired identically; the closing boundary `9|0` is not. -/
theorem closing_seam_offset :
    (∀ m < 9, seamWiring m = seamWiring 0) ∧ seamWiring 9 ≠ seamWiring 0 ∧
    (16, 1) ∈ seamWiring 0 ∧ (16, 3) ∈ seamWiring 9 := by
  native_decide

/-- The module shift is not a symmetry of the coloured lattice. -/
theorem shift_not_symmetry : ¬ ∀ a b c, Bond a b c → Bond (shift a) (shift b) c := by
  intro h
  have := (rigid shift id (fun c hc => hc) (by decide) h).2 0 (by decide)
  revert this; native_decide

end Stellarator
