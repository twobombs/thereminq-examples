
import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic
import Mathlib.Algebra.Group.Nat.Even

/-!
# Pauli commutation and Kitaev's loop theorem (general, no data)

* `pauli_comm` : single-qubit Pauli matrices commute when equal and anticommute
  when different. Two tensor-product Pauli strings therefore commute exactly
  when the number of sites carrying two different non-identity letters is even.
  `anti` is that site-wise test and is the only commutation criterion used in
  the data checks.

* `kitaev_loop_commutes` : on any graph with a proper 3-edge-colouring
  (`nbr v c` = colour-`c` neighbour, an involution), take any edge set `C` in
  which every vertex has degree 0 or 2 (a cycle, or a disjoint union of cycles,
  possibly with chords elsewhere). Put on each degree-2 vertex the Pauli of the
  one colour that leaves `C`. The resulting loop operator `W_C` commutes with
  every Kitaev bond term `σ^c_v σ^c_{nbr v c}`. This is the reason the flux
  sector `{W_p}` is conserved by the Trotter circuits, seams included.
-/

namespace Stellarator.Pauli

open Matrix Complex

/-! ## Matrices -/

/-- σ^x, σ^y, σ^z -/
def sigma : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ
  | 0 => !![0, 1; 1, 0]
  | 1 => !![0, -I; I, 0]
  | 2 => !![1, 0; 0, -1]

set_option linter.unusedTactic false in
theorem pauli_comm (a b : Fin 3) :
    (a = b → sigma a * sigma b = sigma b * sigma a) ∧
    (a ≠ b → sigma a * sigma b = -(sigma b * sigma a)) := by
  fin_cases a <;> fin_cases b <;>
    refine ⟨fun h => ?_, fun h => ?_⟩ <;>
    first
    | (exfalso; simp at h; done)
    | rfl
    | (ext i j; fin_cases i <;> fin_cases j <;>
        simp [sigma, Matrix.mul_apply, Fin.sum_univ_two]; done)

/-! ## Site-wise letters -/

/-- single-site letter: `none` = identity, `some c` = σ^c -/
abbrev P1 := Option (Fin 3)

/-- the two letters anticommute -/
def anti : P1 → P1 → Bool
  | some a, some b => a != b
  | _, _ => false

theorem anti_symm (p q : P1) : anti p q = anti q p := by
  cases p <;> cases q <;> simp [anti, bne, BEq.comm]

/-- 0 or 2 of the three colours at a site belong to the edge set -/
def degOK (b0 b1 b2 : Bool) : Bool :=
  (b0.toNat + b1.toNat + b2.toNat == 0) || (b0.toNat + b1.toNat + b2.toNat == 2)

/-- loop-operator letter at a site from its three in-set flags -/
def wLetter : Bool → Bool → Bool → P1
  | true, true, false => some 2
  | true, false, true => some 1
  | false, true, true => some 0
  | _, _, _ => none

def flag (b0 b1 b2 : Bool) : Fin 3 → Bool
  | 0 => b0
  | 1 => b1
  | 2 => b2

/-- At a degree-0/2 site, the loop letter anticommutes with σ^c iff edge `c` is in the set. -/
theorem key (b0 b1 b2 : Bool) (c : Fin 3) (h : degOK b0 b1 b2 = true) :
    anti (wLetter b0 b1 b2) (some c) = flag b0 b1 b2 c := by
  revert h; revert b0 b1 b2 c; decide

/-! ## Kitaev's theorem on an arbitrary colour graph -/

section General

variable {V : Type*} (nbr : V → Fin 3 → V)

/-- an edge set in which every vertex has degree 0 or 2 -/
structure EvenSet where
  mem : V → Fin 3 → Bool
  symm : ∀ v c, mem (nbr v c) c = mem v c
  deg : ∀ v, degOK (mem v 0) (mem v 1) (mem v 2) = true

variable {nbr}

/-- loop operator `W_C` as a letter at each site -/
def EvenSet.W (C : EvenSet nbr) (v : V) : P1 := wLetter (C.mem v 0) (C.mem v 1) (C.mem v 2)

theorem EvenSet.flag_eq (C : EvenSet nbr) (v : V) (c : Fin 3) :
    flag (C.mem v 0) (C.mem v 1) (C.mem v 2) c = C.mem v c := by
  fin_cases c <;> rfl

theorem EvenSet.anti_W (C : EvenSet nbr) (v : V) (c : Fin 3) :
    anti (C.W v) (some c) = C.mem v c := by
  rw [EvenSet.W, key _ _ _ _ (C.deg v), C.flag_eq]

/-- **Kitaev.** The bond term `σ^c_v σ^c_w` (`w = nbr v c`) meets `W_C` in an even number
of anticommuting sites, so it commutes with `W_C`. -/
theorem kitaev_loop_commutes (C : EvenSet nbr) (v : V) (c : Fin 3) :
    Even ((if anti (C.W v) (some c) then 1 else 0) +
          (if anti (C.W (nbr v c)) (some c) then 1 else 0)) := by
  rw [C.anti_W, C.anti_W, C.symm]
  cases C.mem v c <;> simp

end General

/-! ## Pauli strings as site lists -/

/-- number of anticommuting sites between a string `(sites, letters)` and a letter field -/
def antiCount (sites : List Nat) (letter : Nat → P1) (field : Nat → P1) : Nat :=
  (sites.filter (fun s => anti (letter s) (field s))).length

end Stellarator.Pauli
