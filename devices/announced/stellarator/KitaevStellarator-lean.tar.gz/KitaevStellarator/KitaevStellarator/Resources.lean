import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic
import KitaevStellarator.Modules

/-!
# Resource arithmetic of the distributed machine (kernel-checked)

* `qpd_sum`, `qpd_gamma` : the six LO-QPD coefficients the code samples for a seam
  rotation `exp(-iθ P_a P_b)` sum to 1 and have 1-norm `γ(θ) = 1 + 2|sin 2θ|`
* `gamma_bounds`, `gamma_prod_le` : `1 ≤ γ ≤ 3`, so `Γ_LO ≤ 3^(#cuts)`
* `seam_count`  : 520 seam bonds per Trotter layer (320 K4 + 200 toroidal)
* `sv_bytes`, `die_layout` : 27-qubit `complex64` state vector = 1 GiB; 40 blocks fit on
  6 dies of 8 GiB at 6 or 7 blocks per die
* `memory_rows` : the `T_mem / t_round ≥ 3(r+1) / (2 ε_req)` column of the link budget
  and its fault-tolerance flags
-/

namespace Stellarator.Resources
open Real

/-! ## LO-QPD -/

/-- coefficients `(cos²θ, sin²θ, ±½ sin 2θ, ±½ sin 2θ)` used by the sampler -/
noncomputable def qpdCoeffs (θ : ℝ) : List ℝ :=
  [cos θ ^ 2, sin θ ^ 2, sin (2 * θ) / 2, -(sin (2 * θ) / 2), sin (2 * θ) / 2, -(sin (2 * θ) / 2)]

/-- per-cut sampling overhead -/
noncomputable def gamma (θ : ℝ) : ℝ := 1 + 2 * |sin (2 * θ)|

theorem qpd_sum (θ : ℝ) : (qpdCoeffs θ).sum = 1 := by
  simp only [qpdCoeffs, List.sum_cons, List.sum_nil]
  nlinarith [sin_sq_add_cos_sq θ]

theorem qpd_gamma (θ : ℝ) : ((qpdCoeffs θ).map (fun x => |x|)).sum = gamma θ := by
  simp only [qpdCoeffs, gamma, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil,
    abs_neg, abs_div, abs_two]
  rw [abs_of_nonneg (sq_nonneg _), abs_of_nonneg (sq_nonneg _)]
  nlinarith [sin_sq_add_cos_sq θ]

theorem gamma_bounds (θ : ℝ) : 1 ≤ gamma θ ∧ gamma θ ≤ 3 := by
  have h := abs_sin_le_one (2 * θ)
  have h0 := abs_nonneg (sin (2 * θ))
  unfold gamma; constructor <;> linarith

theorem gamma_zero : gamma 0 = 1 := by simp [gamma]

theorem gamma_quarter : gamma (π / 4) = 3 := by
  have : 2 * (π / 4) = π / 2 := by ring
  simp [gamma, this]; norm_num

/-- `Γ_LO = ∏_c γ(θ_c) ≤ 3^(#cuts)` -/
theorem gamma_prod_le (θs : List ℝ) : (θs.map gamma).prod ≤ 3 ^ θs.length := by
  induction θs with
  | nil => simp
  | cons θ t ih =>
    simp only [List.map_cons, List.prod_cons, List.length_cons, pow_succ]
    have h1 := gamma_bounds θ
    have h2 : 0 ≤ (t.map gamma).prod :=
      List.prod_nonneg (fun x hx => by
        obtain ⟨y, -, rfl⟩ := List.mem_map.mp hx; linarith [(gamma_bounds y).1])
    nlinarith

/-! ## Seams, memory and the link budget -/

/-- one teleported or knitted cut per seam bond per Trotter layer: 520 = 320 + 200 -/
theorem seam_count : kindCount 1 + kindCount 2 = 520 ∧ 520 * 10 = 5200 := by
  rw [bond_classes.2.1, bond_classes.2.2.1]; decide

def GiB : Nat := 2 ^ 30

theorem sv_bytes : 2 ^ 27 * 8 = GiB ∧ 2 ^ 28 * 8 = 2 * GiB ∧ 2 ^ 28 * 16 = 4 * GiB := by
  unfold GiB; norm_num

/-- 4 dies × 7 + 2 dies × 6 = 40 blocks, at most 7 GiB on an 8 GiB die -/
theorem die_layout : 4 * 7 + 2 * 6 = 40 ∧ 7 * (2 ^ 27 * 8) ≤ 8 * GiB ∧ 40 > 6 * 6 := by
  unfold GiB; norm_num

/-- storage requirement `3 (r + 1) / (2 ε)` with `ε = 10⁻² / N_ebits` -/
noncomputable def tmemRatio (nEbits r : ℕ) : ℝ := 3 * (r + 1) / (2 * ((1 / 100) / nEbits))

theorem memory_rows :
    tmemRatio 3 2 = 1350 ∧ tmemRatio 12 2 = 5400 ∧ tmemRatio 64 3 = 38400 ∧
    tmemRatio 320 3 = 192000 ∧ tmemRatio 5200 3 = 3120000 := by
  unfold tmemRatio; norm_num

/-- `ε_req < 10⁻³` (fault-tolerant Bell pairs needed) exactly for the rows with ≥ 12 ebits -/
theorem ft_flags :
    ¬ ((1 / 100 : ℝ) / 3 < 1 / 1000) ∧ (1 / 100 : ℝ) / 12 < 1 / 1000 ∧
    (1 / 100 : ℝ) / 64 < 1 / 1000 ∧ (1 / 100 : ℝ) / 5200 < 1 / 1000 := by
  norm_num

/-- at a 1 µs classical round the full machine needs ≈ 3.12 s of pair-memory coherence -/
theorem full_machine_coherence : tmemRatio 5200 3 * (1 / 1000000) = 3.12 := by
  unfold tmemRatio; norm_num

end Stellarator.Resources
