# λ = 1 at every depth
python3 nighthawk_qrack.py run --backend ace --register nighthawk61r2 --families hamming --protocol nnqab \
  --depths 4 6 8 10 12 --fold 1 --instances 3 --order shallow \
  --cpu --gpus 0 --per-gpu 1 --swap-gb 238 --mem-budget-gb 530 --out dan_hamming_61.jsonl