python3 nighthawk_qrack.py run --backend ace --families mirror --sizes 61 \
  --depths 4 6 8 12 16 20 --lrc 4 --lrr 4 --ace-tiling \
  --gpus 0 --per-gpu 2 --mem-budget-gb 300 --out mirror_tiled.jsonl