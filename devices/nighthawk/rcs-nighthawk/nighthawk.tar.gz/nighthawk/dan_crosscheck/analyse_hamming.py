# Dan Strano's mirror Hamming-weight observable on the two-patch ladder (run --families hamming --protocol nnqab)
# against his ACE calculator, with his Richardson zero-noise extrapolation in lambda^p.
# Usage: python3 analyse_hamming.py run1.jsonl [run2.jsonl ...]   (default: dan_hamming_*.jsonl, H_*.jsonl)
import glob
import json
import math
import sys

import numpy as np

P = 1.60569


def dan(bulk, bnd, patches, d):
    x = (bulk / (bnd * patches)) ** (2 / 3)
    y = math.tanh(0.1653638846 * x - 0.0378757892)
    return 0.0 if y <= 0 else y ** ((d / 12) ** P)


def richardson(lams, ys, p=P):
    u = [l ** p for l in lams]
    w = [math.prod(uj / (uj - ui) for j, uj in enumerate(u) if j != i) for i, ui in enumerate(u)]
    return sum(wi * yi for wi, yi in zip(w, ys))


files = sys.argv[1:] or sorted(glob.glob("dan_hamming_*.jsonl") + glob.glob("H_*.jsonl"))
data, geo = {}, {}
for f in files:
    for line in open(f):
        if not line.startswith("{"):
            continue
        r = json.loads(line)
        if r.get("family") != "hamming" or r.get("protocol") != "nnqab":
            continue
        if not math.isfinite(r["fidelity"]):          # a broken run's record: ignored, rerun replaces it
            continue
        n = r["n"]
        geo[n] = (r["ace_seam_used"], r["ace_sims_used"])
        data.setdefault(n, {}).setdefault((r["depth"], r.get("fold", r["K"])), {})[r["instance"]] = r["fidelity"]

fmt = lambda m, se: f"{m:.3f} ± {se:.3f}"
print("signal 1 - 2h at lambda = 1, plain mean over circuits; Dan's calculator at d (and at 2d)")
for n in sorted(data):
    B, Ps = geo[n]
    pts = []
    print(f"n {n}: seam {B}, patches {Ps}")
    for (d, lam) in sorted(k for k in data[n] if k[1] == 1):
        v = np.array(list(data[n][(d, 1)].values()))
        m, se = v.mean(), (v.std(ddof=1) / math.sqrt(len(v)) if len(v) > 1 else float("nan"))
        a, b = dan(n - B, B, Ps, d), dan(n - B, B, Ps, 2 * d)
        print(f"   d {d:>2}  {fmt(m, se)}  ({len(v)})  Dan(d) {a:.3f}  ratio {m / a:.2f}  Dan(2d) {b:.4f}")
        if 0 < m < 1 and d >= 6:
            pts.append((math.log(d / 12), math.log(-math.log(m))))
    if len(pts) >= 2:
        X, Y = np.array(pts).T
        p, c = np.polyfit(X, Y, 1)
        print(f"   fitted p {p:.2f}, signal(12) {math.exp(-math.exp(c)):.3f}  (Dan: {P}, {dan(n - B, B, Ps, 12):.3f})")
print("\nfolding: signal at lambda = 1 / 3 / 5 and Richardson (ln signal, u = lambda^p) to lambda = 0")
for n in sorted(data):
    for d in sorted({k[0] for k in data[n]}):
        lams = sorted(l for (dd, l) in data[n] if dd == d)
        ms = [float(np.mean(list(data[n][(d, l)].values()))) for l in lams]
        mit = math.exp(richardson(lams, [math.log(x) for x in ms])) if len(lams) > 1 and min(ms) > 0 else float("nan")
        print(f"n {n:>2} d {d:>2}  " + " / ".join(f"{x:.3f}" for x in ms) + f"   mitigated {mit:.3f}")
