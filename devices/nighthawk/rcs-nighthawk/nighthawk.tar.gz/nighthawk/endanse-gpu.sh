for n in 49 ; do
  python3 nighthawk_qrack.py run --backend ace --register nighthawk2p$n --families hamming --protocol nnqab \
    --depths 4 6 8 10 12 --fold 1 3 5 --instances 10 --order shallow \
    --ace-gpu --gpus 0-5 --per-gpu 2 --mem-budget-gb 290 --out dan_hamming_${n}.jsonl
done
