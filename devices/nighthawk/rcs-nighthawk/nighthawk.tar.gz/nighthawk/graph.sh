python3 - <<'EOF'
import glob, json
with open("mirror61_dan_d16.jsonl", "w") as f:
    for fn in glob.glob("mirror61_dan_prob_cpu*.jsonl"):
        for line in open(fn):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("depth", 0) <= 16:
                f.write(line if line.endswith("\n") else line + "\n")
EOF
OCL_ICD_VENDORS=/tmp/no-icd python3 nighthawk_graph.py --out mirror61_dan_d16.jsonl \
    --cfg ace-4b19e847 --figs 1,3 --save plots_mirror61_d16