#!/usr/bin/env bash
# check.sh -- state of nighthawk_fullsweep.sh, from the live claim files only.
# A claim file is named n<n>_mirror_K0_d<dd>_p0_i<i> (no dot). Files with a dot are
# history: <name>.stale<pid> is a claim that was taken over (including failed claims
# cleared by --retry-failed), <name>.tmp<pid> a write in progress. They are not counted.
cd "$(dirname "$0")"
declare -A why
for f in clean_ace_seam5 clean_ace_seam6 clean_ace_seam7 clean_ace_c7r4 clean_ace_c4r7; do
  done_=0; run=0; dead=0; fail=0
  for c in ${f}_shots/*/claims/*; do
    [ -f "$c" ] || continue
    case "$(basename "$c")" in *.*) continue ;; esac
    t=$(cat "$c" 2>/dev/null)
    case "$t" in
      done) done_=$((done_+1)) ;;
      failed*) fail=$((fail+1)); why["$t"]=$(( ${why["$t"]:-0} + 1 )) ;;
      *) pid=${t%%:*}; if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then run=$((run+1)); else dead=$((dead+1)); fi ;;
    esac
  done
  recs=$(cat $f.jsonl $f.w*.jsonl 2>/dev/null | wc -l)
  printf "%-16s %3d done (%d records)  %3d running  %3d failed  %3d orphaned\n" "$f:" "$done_" "$recs" "$run" "$fail" "$dead"
done
if [ ${#why[@]} -gt 0 ]; then
  echo "current failure reasons:"
  for k in "${!why[@]}"; do printf "%6d  %s\n" "${why[$k]}" "$k"; done | sort -rn
fi
echo "(orphaned = claim of a worker that is gone; the next worker takes it over)"