for n in 57; do
  python3 nighthawk_qrack.py run --backend ace --register nighthawk2p$n --families hamming --protocol nnqab \
    --depths 4 6 8 10 12 --fold 1 3 5 --instances 3 --order shallow \
    --cpu --retry-failed --gpus 0 --per-gpu 1 --mem-budget-gb 290 --out dan_hamming_${n}.jsonl
done
