python3 nighthawk_qrack.py run --backend ace --families fxeb \
  --sizes 27-30 --depths 8 12 16 20 \
  --lrc 4 --lrr 4 --ace-tiling \
  --gpus 0 --per-gpu 3 --max-rss-gb 40 --out big_tile.jsonl