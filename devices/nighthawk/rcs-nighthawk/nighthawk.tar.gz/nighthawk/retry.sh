pkill -f "nighthawk_qrack.py run"
EXTRA=--retry-failed ./nighthawk_sweep.sh

