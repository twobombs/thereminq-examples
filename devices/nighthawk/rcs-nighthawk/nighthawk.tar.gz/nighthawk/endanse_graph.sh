# PNGs of views 12 and 13 from every dan_hamming_*.jsonl in this folder
python3 nighthawk_graph.py --out dan_hamming_36.jsonl --out dan_hamming_40.jsonl --out dan_hamming_45.jsonl \
  --out dan_hamming_49.jsonl --out dan_hamming_53.jsonl --save plots_hamming --figs 12,13

# the viewer, which can auto-reload every 60 s while 57 and 61 run
python3 nighthawk_graph.py --out dan_hamming_36.jsonl --out dan_hamming_40.jsonl --out dan_hamming_45.jsonl \
  --out dan_hamming_49.jsonl --out dan_hamming_53.jsonl --figs 12

# everything at once: harvests every *.jsonl in the folder, writes all 13 views
python3 nighthawk_graph.py --save plots_all

# ACE at 61 qubits against ibm_phoenix (mirror survival + the device fit + PyQrack re-score of its counts)
python3 nighthawk_qrack.py hwxeb --out hwxeb.json
python3 nighthawk_graph.py --out mirror61r2_haar.jsonl --out ladder_61_haar.jsonl --hwxeb hwxeb.json --save plots_device --figs 1,6

# forward XEB of the release circuits against the device's fit
python3 nighthawk_graph.py --save plots_device --figs 8-10 --theta haar
