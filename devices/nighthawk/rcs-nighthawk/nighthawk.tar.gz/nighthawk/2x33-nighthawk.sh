python3 nighthawk_qrack.py run --backend ace --families fxeb \
  --sizes 27-34 --depths 8 12 16 20 \
  --lrc 2 --lrr 7 --ace-tiling \
  --per-gpu 1 --gpus 0 --max-rss-gb 280 --out big_tile.jsonl