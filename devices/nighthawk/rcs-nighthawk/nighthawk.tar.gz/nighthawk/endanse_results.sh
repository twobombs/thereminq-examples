for n in 36 45 49 53 57; do
  python3 nighthawk_qrack.py run --backend ace --register nighthawk2p$n --families hamming --protocol nnqab \
    --depths 4 6 8 10 12 --fold 1 3 5 --instances 10 --cpu --out dan_hamming_${n}.jsonl --summarize
done

python3 nighthawk_qrack.py danmodel --in dan_hamming_36.jsonl dan_hamming_45.jsonl dan_hamming_49.jsonl dan_hamming_53.jsonl dan_hamming_57.jsonl
python3 dan_crosscheck/analyse_hamming.py dan_hamming_*.jsonl