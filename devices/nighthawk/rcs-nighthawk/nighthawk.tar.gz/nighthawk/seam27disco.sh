for L in "4 4" "2 7" "1 7" "4 3" "2 2"; do
  set -- $L
  python3 nighthawk_qrack.py run --backend ace --families fxeb \
    --n 27 --depths 8 12 --lrc $1 --lrr $2 --cpu --ace-tiling \
    --out tile_${1}_${2}.jsonl > tile_${1}_${2}.log 2>&1 &
done
wait

for L in "4 4" "2 7" "1 7" "4 3" "2 2"; do
  set -- $L
  echo "== lrc $1 lrr $2 tiled"
  grep -m1 "^# ace tiling" tile_${1}_${2}.log
  python3 nighthawk_qrack.py run --backend ace --families fxeb \
    --n 27 --depths 8 12 --lrc $1 --lrr $2 --cpu --ace-tiling \
    --out tile_${1}_${2}.jsonl --summarize 2>/dev/null | grep -E "^27 "
done


