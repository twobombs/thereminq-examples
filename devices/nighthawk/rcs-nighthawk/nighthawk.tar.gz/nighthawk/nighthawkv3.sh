python3 nighthawk_qrack.py run --backend ace --families fxeb \
  --sizes 27-34 --depths 12 16 20 \
  --variants 4/4:t3 4/4:t2 \
  --gpus 0 --per-gpu 4 --mem-budget-gb 300 --max-rss-gb 300 \
  --out big_var.jsonl